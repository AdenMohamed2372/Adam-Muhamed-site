
import React from "react";
import './App.css';

function App() {
  return (
    <div className="App" style={{ background: 'linear-gradient(to bottom, #0d1b2a, #4b2e2e)', color: 'white', minHeight: '100vh', padding: '2rem' }}>
      <header style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>Adam Muhamed Hosting</h1>
        <p style={{ fontSize: '1.1rem' }}>Fast, secure, and reliable web hosting for your needs</p>
      </header>

      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '1.5rem' }}>
        <div style={{ backgroundColor: '#1b263b', padding: '1rem', borderRadius: '10px' }}>
          <h2>Shared Hosting</h2>
          <p>Perfect for small websites and blogs. Get started with easy setup and low cost.</p>
        </div>
        <div style={{ backgroundColor: '#1b263b', padding: '1rem', borderRadius: '10px' }}>
          <h2>VPS Hosting</h2>
          <p>More power and control for developers and growing businesses.</p>
        </div>
        <div style={{ backgroundColor: '#1b263b', padding: '1rem', borderRadius: '10px' }}>
          <h2>Dedicated Servers</h2>
          <p>Ultimate performance and full control with your own physical server.</p>
        </div>
      </section>

      <footer style={{ marginTop: '5rem', textAlign: 'center', fontSize: '0.9rem', color: '#aaa' }}>
        &copy; {new Date().getFullYear()} Adam Muhamed Hosting. All rights reserved.
      </footer>
    </div>
  );
}

export default App;
